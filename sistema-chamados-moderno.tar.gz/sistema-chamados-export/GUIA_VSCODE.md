# 🚀 Guia de Início Rápido - VSCode

## 📥 Importar Projeto no VSCode

### Passo 1: Abrir a Pasta
1. Abra o VSCode
2. Clique em `File` → `Open Folder`
3. Selecione a pasta `sistema-chamados-moderno`
4. Clique em `Select Folder`

### Passo 2: Instalar Extensões Recomendadas
Instale as seguintes extensões no VSCode:

- **ES7+ React/Redux/React-Native snippets** (dsznajder.es7-react-js-snippets)
- **Tailwind CSS IntelliSense** (bradlc.vscode-tailwindcss)
- **TypeScript Vue Plugin** (Vue.volar)
- **Prettier - Code formatter** (esbenp.prettier-vscode)
- **ESLint** (dbaeumer.vscode-eslint)
- **Thunder Client** (rangav.vscode-thunder-client) - Para testar APIs

### Passo 3: Instalar Dependências
Abra o terminal integrado (`` Ctrl+` ``) e execute:

```bash
pnpm install
```

### Passo 4: Configurar Variáveis de Ambiente
1. Crie um arquivo `.env` na raiz do projeto
2. Copie o conteúdo abaixo e preencha com seus dados:

```env
# Banco de Dados
DATABASE_URL=mysql://usuario:senha@localhost:3306/chamados

# Autenticação
JWT_SECRET=sua-chave-secreta-super-segura-aqui
VITE_APP_ID=seu-app-id-manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# Stripe
STRIPE_SECRET_KEY=sk_test_sua_chave_aqui
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave_aqui
STRIPE_WEBHOOK_SECRET=whsec_sua_chave_aqui

# Owner
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu-open-id
```

### Passo 5: Executar Migrações
```bash
pnpm db:push
```

### Passo 6: Iniciar Desenvolvimento
```bash
pnpm dev
```

A aplicação estará disponível em `http://localhost:3000`

---

## 🎯 Estrutura de Pastas Explicada

### `client/src/pages/`
Aqui estão todas as páginas da aplicação:
- `Home.tsx` - Página inicial
- `Dashboard.tsx` - Dashboard com gráficos
- `TicketsList.tsx` - Listagem de chamados
- `TicketDetail.tsx` - Detalhes do chamado
- `CreateTicket.tsx` - Formulário de novo chamado
- `Pricing.tsx` - Página de planos
- `Billing.tsx` - Gerenciamento de faturamento

### `server/`
Código do backend:
- `routers.ts` - Definição de todas as rotas tRPC
- `db.ts` - Funções de acesso ao banco de dados
- `products.ts` - Configuração dos planos de assinatura

### `drizzle/`
Banco de dados:
- `schema.ts` - Definição das tabelas
- `migrations/` - Histórico de mudanças no schema

---

## 💻 Fluxo de Desenvolvimento

### 1. Criar Nova Página
```bash
# Crie um novo arquivo em client/src/pages/NomePagina.tsx
```

Exemplo:
```typescript
import { Button } from "@/components/ui/button";

export default function NomePagina() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto py-8">
        <h1 className="text-4xl font-bold">Minha Página</h1>
      </div>
    </div>
  );
}
```

### 2. Registrar Rota
Edite `client/src/App.tsx`:
```typescript
import NomePagina from "./pages/NomePagina";

function Router() {
  return (
    <Switch>
      <Route path={"/minha-pagina"} component={NomePagina} />
      {/* outras rotas */}
    </Switch>
  );
}
```

### 3. Criar Nova Rota tRPC
Edite `server/routers.ts`:
```typescript
minhaFeature: router({
  list: publicProcedure.query(async () => {
    // sua lógica aqui
    return [];
  }),
  create: protectedProcedure
    .input((val: any) => ({ name: val.name }))
    .mutation(async ({ input, ctx }) => {
      // sua lógica aqui
      return { success: true };
    }),
}),
```

### 4. Usar no Frontend
```typescript
import { trpc } from "@/lib/trpc";

export default function MeuComponente() {
  const { data } = trpc.minhaFeature.list.useQuery();
  const mutation = trpc.minhaFeature.create.useMutation();

  const handleCreate = () => {
    mutation.mutate({ name: "Novo Item" });
  };

  return (
    <button onClick={handleCreate}>
      Criar
    </button>
  );
}
```

---

## 🧪 Executar Testes

```bash
# Executar todos os testes
pnpm test

# Modo watch (atualiza ao salvar)
pnpm test --watch

# Teste específico
pnpm test auth
```

---

## 🔍 Debug

### Debug no VSCode
1. Clique no ícone de Debug na barra lateral (ou `Ctrl+Shift+D`)
2. Clique em "Run and Debug"
3. Selecione "Node.js"
4. Defina breakpoints clicando na linha de código

### Console do Navegador
Abra o DevTools do navegador (`F12`) para ver logs do frontend.

---

## 📦 Build para Produção

```bash
# Build
pnpm build

# Testar build localmente
pnpm start
```

---

## 🎨 Customizar Tema

Edite `client/src/index.css` para mudar cores:

```css
@layer base {
  :root {
    --primary: 168 85 247;      /* Roxo */
    --secondary: 236 72 153;    /* Rosa */
    --success: 16 185 129;      /* Verde */
    /* ... outras cores */
  }
}
```

---

## 🚀 Deploy Rápido

### Deploy no Manus
1. Abra o Management UI
2. Clique em "Publish"
3. Escolha um domínio
4. Confirme

### Deploy no Vercel
```bash
npm install -g vercel
vercel
```

---

## 📚 Atalhos Úteis do VSCode

| Atalho | Ação |
|--------|------|
| `Ctrl+K Ctrl+S` | Ver todos os atalhos |
| `Ctrl+Shift+P` | Command Palette |
| `Ctrl+/` | Comentar/Descomentar |
| `Alt+Shift+F` | Formatar código |
| `Ctrl+Shift+L` | Selecionar todas as ocorrências |
| `F2` | Renomear variável |
| `Ctrl+G` | Ir para linha |

---

## 🆘 Problemas Comuns

### "Port 3000 is already in use"
```bash
# Matar processo na porta 3000
lsof -ti:3000 | xargs kill -9
```

### "Module not found"
```bash
# Limpar node_modules e reinstalar
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### "TypeScript errors"
```bash
# Verificar erros
pnpm check

# Recompilar
pnpm build
```

---

## 📞 Próximos Passos

1. ✅ Instale as dependências
2. ✅ Configure o `.env`
3. ✅ Execute as migrações
4. ✅ Inicie o servidor
5. ✅ Abra `http://localhost:3000`
6. ✅ Comece a desenvolver!

---

**Boa sorte com seu projeto! 🚀**
