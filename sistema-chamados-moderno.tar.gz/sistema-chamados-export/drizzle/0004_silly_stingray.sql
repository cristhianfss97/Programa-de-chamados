DROP TABLE `payments`;--> statement-breakpoint
DROP TABLE `subscription_plans`;--> statement-breakpoint
DROP TABLE `user_subscriptions`;