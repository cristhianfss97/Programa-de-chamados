DROP TABLE `ticket_categories`;--> statement-breakpoint
DROP TABLE `ticket_history`;--> statement-breakpoint
DROP TABLE `tickets`;