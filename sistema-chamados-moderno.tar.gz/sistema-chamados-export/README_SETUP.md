# 🎯 Sistema de Gerenciamento de Chamados - Setup Completo

## 📋 Índice
1. [Pré-requisitos](#pré-requisitos)
2. [Instalação](#instalação)
3. [Configuração](#configuração)
4. [Execução](#execução)
5. [Estrutura do Projeto](#estrutura-do-projeto)
6. [Funcionalidades](#funcionalidades)

---

## 🔧 Pré-requisitos

Certifique-se de ter instalado:

- **Node.js** 18+ ([Download](https://nodejs.org))
- **pnpm** 8+ (instale com `npm install -g pnpm`)
- **Git** ([Download](https://git-scm.com))
- **MySQL** 8+ ou **TiDB** (banco de dados)

### Verificar Instalação

```bash
node --version      # Deve ser v18 ou superior
pnpm --version      # Deve ser 8 ou superior
git --version       # Qualquer versão recente
```

---

## 📥 Instalação

### 1. Clonar ou Extrair o Projeto

Se você tem um arquivo ZIP:
```bash
unzip sistema-chamados-moderno.zip
cd sistema-chamados-moderno
```

Se você tem um repositório Git:
```bash
git clone https://seu-repositorio.git
cd sistema-chamados-moderno
```

### 2. Instalar Dependências

```bash
pnpm install
```

Isso instalará:
- React 19 e dependências do frontend
- Express.js e dependências do backend
- Drizzle ORM para banco de dados
- Tailwind CSS para estilos
- E muito mais...

**Tempo estimado:** 3-5 minutos

---

## ⚙️ Configuração

### 1. Criar Arquivo de Ambiente

Copie o arquivo `.env.example` para `.env`:

```bash
cp .env.example .env
```

### 2. Configurar Banco de Dados

Edite o arquivo `.env` e configure a conexão:

```env
DATABASE_URL=mysql://usuario:senha@localhost:3306/chamados_db
```

**Exemplo para MySQL local:**
```env
DATABASE_URL=mysql://root:senha123@localhost:3306/chamados
```

**Exemplo para TiDB Cloud:**
```env
DATABASE_URL=mysql://user@host:password@tidb-host:4000/chamados
```

### 3. Configurar Autenticação (Manus OAuth)

1. Acesse [Manus Dashboard](https://dashboard.manus.im)
2. Crie uma nova aplicação
3. Copie o `App ID`
4. Configure no `.env`:

```env
VITE_APP_ID=seu-app-id-aqui
```

### 4. Configurar Stripe (Pagamentos)

1. Crie conta em [Stripe](https://stripe.com)
2. Acesse [Stripe Dashboard](https://dashboard.stripe.com)
3. Vá para Developers → API Keys
4. Copie as chaves de teste:

```env
STRIPE_SECRET_KEY=sk_test_sua_chave_aqui
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_sua_chave_aqui
```

5. Configure webhooks:
   - Vá em Developers → Webhooks
   - Crie novo webhook para `http://localhost:3000/api/stripe/webhook`
   - Copie o `Signing Secret`:

```env
STRIPE_WEBHOOK_SECRET=whsec_sua_chave_aqui
```

### 5. Gerar JWT Secret

```bash
# No terminal, execute:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copie o resultado e adicione ao `.env`:

```env
JWT_SECRET=seu-resultado-aqui
```

---

## 🚀 Execução

### 1. Executar Migrações do Banco de Dados

```bash
pnpm db:push
```

Isso criará todas as tabelas necessárias no seu banco de dados.

### 2. Iniciar Servidor de Desenvolvimento

```bash
pnpm dev
```

Você verá algo como:
```
[OAuth] Initialized with baseURL: https://api.manus.im
Server running on http://localhost:3000/
```

### 3. Acessar a Aplicação

Abra seu navegador e vá para:
```
http://localhost:3000
```

---

## 📁 Estrutura do Projeto

```
sistema-chamados-moderno/
│
├── 📂 client/                    # Frontend React
│   ├── src/
│   │   ├── pages/               # Páginas da aplicação
│   │   ├── components/          # Componentes reutilizáveis
│   │   ├── lib/trpc.ts          # Cliente tRPC
│   │   ├── App.tsx              # Componente raiz
│   │   └── index.css            # Estilos globais
│   └── index.html               # HTML template
│
├── 📂 server/                    # Backend Node.js
│   ├── routers.ts               # Rotas tRPC
│   ├── db.ts                    # Funções de banco de dados
│   └── _core/                   # Framework core
│
├── 📂 drizzle/                   # Banco de dados
│   ├── schema.ts                # Definição de tabelas
│   └── migrations/              # Histórico de mudanças
│
├── 📄 package.json              # Dependências
├── 📄 tsconfig.json             # Configuração TypeScript
├── 📄 vite.config.ts            # Configuração Vite
├── 📄 .env                      # Variáveis de ambiente
└── 📄 README.md                 # Este arquivo
```

---

## ✨ Funcionalidades

### 🏠 Home
- Página inicial elegante
- Links para Dashboard e Criar Chamado
- Apresentação do sistema

### 📊 Dashboard
- Gráficos de status de chamados
- Indicadores de prioridade
- Estatísticas em tempo real
- Interface visual atraente

### 🎫 Meus Chamados
- Listagem de todos os chamados
- Filtros por status e prioridade
- Busca por título
- Cards elegantes

### ➕ Criar Novo Chamado
- Formulário intuitivo
- Campos: título, descrição, prioridade, categoria
- Validação automática
- Criação instantânea

### 💰 Planos
- 3 planos profissionais
- Preços mensais e anuais
- Integração com Stripe
- Checkout seguro

### 💳 Faturamento
- Gerenciar assinatura
- Histórico de pagamentos
- Portal Stripe integrado
- Atualizar método de pagamento

---

## 🧪 Testes

### Executar Testes

```bash
pnpm test
```

### Modo Watch (atualiza ao salvar)

```bash
pnpm test --watch
```

### Teste Específico

```bash
pnpm test auth
```

---

## 🔐 Segurança

### Boas Práticas

1. **Nunca commite o `.env`** - Use `.env.example` como template
2. **Mantenha JWT_SECRET seguro** - Use uma chave forte
3. **Use HTTPS em produção** - Sempre criptografe conexões
4. **Valide todas as entradas** - O projeto já faz isso
5. **Atualize dependências regularmente** - Execute `pnpm update`

### Variáveis Sensíveis

Nunca compartilhe ou commite:
- `DATABASE_URL`
- `JWT_SECRET`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`

---

## 📦 Scripts Disponíveis

```bash
# Desenvolvimento
pnpm dev                # Iniciar servidor de desenvolvimento

# Build e Produção
pnpm build              # Build para produção
pnpm start              # Iniciar servidor de produção

# Testes
pnpm test               # Executar testes
pnpm test --watch       # Modo watch

# Banco de Dados
pnpm db:push            # Executar migrações
pnpm db:generate        # Gerar tipos do schema

# Formatação
pnpm format             # Formatar código com Prettier
pnpm check              # Verificar tipos TypeScript
```

---

## 🐛 Troubleshooting

### Erro: "Cannot find module"

```bash
pnpm install
pnpm db:push
```

### Erro: "Port 3000 is already in use"

```bash
# Linux/Mac
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Erro: "Database connection failed"

1. Verifique se MySQL está rodando
2. Confirme as credenciais em `.env`
3. Teste a conexão:
   ```bash
   mysql -u usuario -p -h localhost
   ```

### Erro: "OAuth not configured"

1. Verifique se `VITE_APP_ID` está correto
2. Confirme se está usando a URL correta
3. Teste em modo incógnito do navegador

### Erro: "Stripe key invalid"

1. Verifique se as chaves estão corretas
2. Confirme se está usando chaves de teste (sk_test_, pk_test_)
3. Regenere as chaves se necessário

---

## 🚀 Deploy

### Deploy no Manus (Recomendado)

1. Abra o Management UI
2. Clique em "Publish"
3. Escolha um domínio
4. Confirme

### Deploy no Vercel

```bash
npm install -g vercel
vercel
```

### Deploy no Railway

1. Conecte seu repositório GitHub
2. Configure variáveis de ambiente
3. Deploy automático

---

## 📚 Recursos Adicionais

- [Documentação React](https://react.dev)
- [Documentação Tailwind CSS](https://tailwindcss.com)
- [Documentação tRPC](https://trpc.io)
- [Documentação Drizzle ORM](https://orm.drizzle.team)
- [Documentação Stripe](https://stripe.com/docs)
- [Documentação Express.js](https://expressjs.com)

---

## 💡 Dicas

1. **Use TypeScript** - Aproveite a segurança de tipos
2. **Componentes reutilizáveis** - Crie componentes em `client/src/components/`
3. **Testes** - Escreva testes para funcionalidades críticas
4. **Logs** - Use `console.log()` para debug
5. **DevTools** - Abra F12 para ver logs do navegador

---

## 📞 Suporte

Se tiver dúvidas:

1. Consulte a [DOCUMENTACAO.md](./DOCUMENTACAO.md)
2. Veja o [GUIA_VSCODE.md](./GUIA_VSCODE.md)
3. Verifique os logs do servidor
4. Abra o DevTools do navegador (F12)

---

## ✅ Checklist de Setup

- [ ] Node.js 18+ instalado
- [ ] pnpm instalado
- [ ] Projeto extraído/clonado
- [ ] `pnpm install` executado
- [ ] `.env` configurado
- [ ] Banco de dados criado
- [ ] `pnpm db:push` executado
- [ ] `pnpm dev` iniciado
- [ ] Aplicação acessível em `http://localhost:3000`
- [ ] Login funcionando
- [ ] Criar chamado funcionando

---

**Parabéns! Seu sistema de chamados está pronto! 🎉**

Comece a desenvolver e customize conforme suas necessidades.
