import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { AlertCircle, CheckCircle2, Clock, Zap, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { motion } from "framer-motion";

const COLORS = {
  novo: "#3b82f6",
  em_andamento: "#f59e0b",
  resolvido: "#10b981",
  fechado: "#6b7280",
};

const PRIORITY_COLORS = {
  baixa: "#10b981",
  média: "#f59e0b",
  alta: "#ef4444",
  urgente: "#dc2626",
};

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const { data: tickets = [], isLoading } = trpc.tickets.list.useQuery();

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Calcular estatísticas
  const stats = {
    total: tickets.length,
    novo: tickets.filter((t: any) => t.status === "novo").length,
    em_andamento: tickets.filter((t: any) => t.status === "em_andamento").length,
    resolvido: tickets.filter((t: any) => t.status === "resolvido").length,
    fechado: tickets.filter((t: any) => t.status === "fechado").length,
  };

  // Dados para gráficos
  const statusData = [
    { name: "Novo", value: stats.novo, fill: COLORS.novo },
    { name: "Em Andamento", value: stats.em_andamento, fill: COLORS.em_andamento },
    { name: "Resolvido", value: stats.resolvido, fill: COLORS.resolvido },
    { name: "Fechado", value: stats.fechado, fill: COLORS.fechado },
  ];

  const priorityData = [
    { name: "Baixa", value: tickets.filter((t: any) => t.priority === "baixa").length },
    { name: "Média", value: tickets.filter((t: any) => t.priority === "média").length },
    { name: "Alta", value: tickets.filter((t: any) => t.priority === "alta").length },
    { name: "Urgente", value: tickets.filter((t: any) => t.priority === "urgente").length },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
                Dashboard de Chamados
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Bem-vindo, {user?.name || "Usuário"}! Aqui está um resumo de todos os seus chamados.
              </p>
            </div>
            <Link href="/tickets/new">
              <Button className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                <Plus className="w-4 h-4" />
                Novo Chamado
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Indicadores de Status */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8"
        >
          {/* Total */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Total</p>
                    <p className="text-3xl font-bold text-slate-900 dark:text-white mt-2">
                      {stats.total}
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <AlertCircle className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Novo */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Novo</p>
                    <p className="text-3xl font-bold text-blue-600 dark:text-blue-400 mt-2">
                      {stats.novo}
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <AlertCircle className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Em Andamento */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Em Andamento</p>
                    <p className="text-3xl font-bold text-amber-600 dark:text-amber-400 mt-2">
                      {stats.em_andamento}
                    </p>
                  </div>
                  <div className="p-3 bg-amber-100 dark:bg-amber-900 rounded-lg">
                    <Clock className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Resolvido */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Resolvido</p>
                    <p className="text-3xl font-bold text-green-600 dark:text-green-400 mt-2">
                      {stats.resolvido}
                    </p>
                  </div>
                  <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                    <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Fechado */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Fechado</p>
                    <p className="text-3xl font-bold text-gray-600 dark:text-gray-400 mt-2">
                      {stats.fechado}
                    </p>
                  </div>
                  <div className="p-3 bg-gray-100 dark:bg-gray-900 rounded-lg">
                    <Zap className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Gráficos */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 lg:grid-cols-2 gap-8"
        >
          {/* Gráfico de Status */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Distribuição por Status</CardTitle>
                <CardDescription>Visão geral dos chamados por status</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          {/* Gráfico de Prioridade */}
          <motion.div variants={itemVariants}>
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Distribuição por Prioridade</CardTitle>
                <CardDescription>Chamados agrupados por nível de prioridade</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={priorityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Chamados Recentes */}
        <motion.div variants={itemVariants} className="mt-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Chamados Recentes</CardTitle>
              <CardDescription>Últimos chamados criados</CardDescription>
            </CardHeader>
            <CardContent>
              {tickets.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-600 dark:text-slate-400">Nenhum chamado encontrado</p>
                  <Link href="/tickets/new">
                    <Button className="mt-4 gap-2">
                      <Plus className="w-4 h-4" />
                      Criar Primeiro Chamado
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {tickets.slice(0, 5).map((ticket: any) => (
                    <motion.div
                      key={ticket.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold text-slate-900 dark:text-white">{ticket.title}</h3>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                          Criado em {new Date(ticket.createdAt).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold badge-${ticket.status}`}>
                          {ticket.status.replace("_", " ")}
                        </span>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold badge-${ticket.priority}`}>
                          {ticket.priority}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
