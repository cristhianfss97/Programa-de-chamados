import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

export default function CreateTicket() {
  const [, navigate] = useLocation();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("média");
  const [categoryId, setCategoryId] = useState("");

  const { data: categories = [] } = trpc.categories.list.useQuery();
  const createMutation = trpc.tickets.create.useMutation({
    onSuccess: (data) => {
      toast.success("Chamado criado com sucesso!");
      navigate("/tickets");
    },
    onError: () => {
      toast.error("Erro ao criar chamado");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Por favor, preencha o título");
      return;
    }
    createMutation.mutate({
      title,
      description,
      priority,
      categoryId: categoryId ? parseInt(categoryId) : null,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="container mx-auto py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link href="/tickets">
            <Button variant="ghost" className="gap-2 mb-4">
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white mb-2">
            Criar Novo Chamado
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Preencha os detalhes abaixo para criar um novo chamado
          </p>
        </motion.div>

        {/* Formulário */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-2xl"
        >
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Título */}
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-base font-semibold">
                    Título do Chamado *
                  </Label>
                  <Input
                    id="title"
                    placeholder="Ex: Problema com login"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="h-12"
                    required
                  />
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Descreva brevemente o assunto do chamado
                  </p>
                </div>

                {/* Descrição */}
                <div className="space-y-2">
                  <Label htmlFor="description" className="text-base font-semibold">
                    Descrição Detalhada
                  </Label>
                  <Textarea
                    id="description"
                    placeholder="Descreva o problema com detalhes..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="min-h-32 resize-none"
                  />
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Forneça o máximo de detalhes possível para facilitar a resolução
                  </p>
                </div>

                {/* Prioridade */}
                <div className="space-y-2">
                  <Label htmlFor="priority" className="text-base font-semibold">
                    Prioridade *
                  </Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger id="priority" className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baixa">Baixa</SelectItem>
                      <SelectItem value="média">Média</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                      <SelectItem value="urgente">Urgente</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Selecione o nível de urgência do chamado
                  </p>
                </div>

                {/* Categoria */}
                {categories.length > 0 && (
                  <div className="space-y-2">
                    <Label htmlFor="category" className="text-base font-semibold">
                      Categoria
                    </Label>
                    <Select value={categoryId} onValueChange={setCategoryId}>
                      <SelectTrigger id="category" className="h-10">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat: any) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Categorize seu chamado para melhor organização
                    </p>
                  </div>
                )}

                {/* Botões */}
                <div className="flex gap-4 pt-4">
                  <Link href="/tickets">
                    <Button variant="outline" className="flex-1">
                      Cancelar
                    </Button>
                  </Link>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {createMutation.isPending ? "Criando..." : "Criar Chamado"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
