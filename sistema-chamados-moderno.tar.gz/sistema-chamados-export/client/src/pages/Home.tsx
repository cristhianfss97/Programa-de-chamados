import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Zap, BarChart3, Shield, Clock, Users, Sparkles } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="border-b border-slate-200 dark:border-slate-800 backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 sticky top-0 z-50"
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl text-slate-900 dark:text-white">Chamados</span>
          </div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link href="/tickets">
                  <Button variant="ghost">Meus Chamados</Button>
                </Link>
                <Link href="/pricing">
                  <Button variant="ghost">Planos</Button>
                </Link>
                <Link href="/billing">
                  <Button variant="ghost">Faturamento</Button>
                </Link>
                <Button variant="outline" onClick={logout}>
                  Sair
                </Button>
              </>
            ) : (
              <>
                <Link href="/pricing">
                  <Button variant="ghost">Planos</Button>
                </Link>
                <a href={getLoginUrl()}>
                  <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Entrar
                  </Button>
                </a>
              </>
            )}
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="container mx-auto px-4 py-20 md:py-32"
      >
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1
            variants={itemVariants}
            className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6 leading-tight"
          >
            Sistema Elegante de{" "}
            <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
              Gerenciamento de Chamados
            </span>
          </motion.h1>

          <motion.p
            variants={itemVariants}
            className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto"
          >
            Organize, acompanhe e resolva chamados com uma interface moderna, intuitiva e visualmente atraente. Tudo que você precisa em um único lugar.
          </motion.p>

          <motion.div variants={itemVariants} className="flex gap-4 justify-center flex-wrap">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button size="lg" className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Ir para Dashboard
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link href="/tickets/new">
                  <Button size="lg" variant="outline">
                    Criar Novo Chamado
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button size="lg" className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Começar Agora
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </a>
              </>
            )}
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="container mx-auto px-4 py-20"
      >
        <motion.h2
          variants={itemVariants}
          className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-16"
        >
          Recursos Principais
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg w-fit mb-4">
              <BarChart3 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Dashboard Visual
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Visualize gráficos e indicadores em tempo real para acompanhar o status de todos os seus chamados.
            </p>
          </motion.div>

          {/* Feature 2 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg w-fit mb-4">
              <Zap className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Criação Rápida
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Crie novos chamados em segundos com um formulário intuitivo e campos bem organizados.
            </p>
          </motion.div>

          {/* Feature 3 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg w-fit mb-4">
              <Shield className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Filtros Avançados
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Filtre chamados por status, prioridade e categoria para encontrar exatamente o que precisa.
            </p>
          </motion.div>

          {/* Feature 4 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-amber-100 dark:bg-amber-900 rounded-lg w-fit mb-4">
              <Clock className="w-6 h-6 text-amber-600 dark:text-amber-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Histórico Completo
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Acompanhe todas as alterações e mudanças de status com um histórico detalhado.
            </p>
          </motion.div>

          {/* Feature 5 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-pink-100 dark:bg-pink-900 rounded-lg w-fit mb-4">
              <Users className="w-6 h-6 text-pink-600 dark:text-pink-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Autenticação Segura
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Login seguro via OAuth com suporte a múltiplos usuários e controle de acesso.
            </p>
          </motion.div>

          {/* Feature 6 */}
          <motion.div
            variants={itemVariants}
            className="p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200 dark:border-slate-700"
          >
            <div className="p-3 bg-red-100 dark:bg-red-900 rounded-lg w-fit mb-4">
              <Sparkles className="w-6 h-6 text-red-600 dark:text-red-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">
              Design Elegante
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Interface moderna com animações suaves e tema responsivo para todos os dispositivos.
            </p>
          </motion.div>
        </div>
      </motion.section>

      {/* CTA Section */}
      {!isAuthenticated && (
        <motion.section
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="container mx-auto px-4 py-20"
        >
          <motion.div
            variants={itemVariants}
            className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-12 text-center text-white shadow-2xl"
          >
            <h2 className="text-4xl font-bold mb-4">Pronto para começar?</h2>
            <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
              Faça login agora e comece a gerenciar seus chamados com elegância e eficiência.
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="gap-2">
                Entrar Agora
                <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
          </motion.div>
        </motion.section>
      )}

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-950/50 backdrop-blur-sm"
      >
        <div className="container mx-auto px-4 py-8 text-center text-slate-600 dark:text-slate-400">
          <p>&copy; 2026 Sistema de Chamados. Todos os direitos reservados.</p>
        </div>
      </motion.footer>
    </div>
  );
}
