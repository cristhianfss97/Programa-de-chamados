import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { motion } from "framer-motion";
import { Check, ArrowRight, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Pricing() {
  const { isAuthenticated } = useAuth();

  const plans = [
    {
      name: "Básico",
      price: "49",
      description: "Perfeito para pequenas equipes",
      features: [
        "Até 100 chamados/mês",
        "Até 3 usuários",
        "Dashboard básico",
        "Suporte por email",
        "Histórico de 30 dias",
      ],
      popular: false,
      color: "from-blue-600 to-blue-700",
    },
    {
      name: "Profissional",
      price: "149",
      description: "Para equipes em crescimento",
      features: [
        "Até 1.000 chamados/mês",
        "Até 10 usuários",
        "Dashboard avançado com gráficos",
        "Relatórios personalizados",
        "Suporte por email e chat",
        "Histórico completo",
        "API access",
        "Categorias customizadas",
      ],
      popular: true,
      color: "from-purple-600 to-pink-600",
    },
    {
      name: "Enterprise",
      price: "499",
      description: "Para grandes organizações",
      features: [
        "Chamados ilimitados",
        "Usuários ilimitados",
        "Todos os recursos Profissional",
        "Suporte prioritário 24/7",
        "SLA garantido",
        "Integração com sistemas externos",
        "Webhooks customizados",
        "Análise avançada de dados",
      ],
      popular: false,
      color: "from-pink-600 to-red-600",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="border-b border-slate-200 dark:border-slate-800 backdrop-blur-sm bg-white/50 dark:bg-slate-950/50 sticky top-0 z-50"
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="p-2 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl text-slate-900 dark:text-white">Chamados</span>
            </div>
          </Link>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="ghost">Dashboard</Button>
                </Link>
                <Link href="/billing">
                  <Button variant="ghost">Faturamento</Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  Entrar
                </Button>
              </a>
            )}
          </div>
        </div>
      </motion.nav>

      {/* Header */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="container mx-auto px-4 py-20 text-center"
      >
        <motion.h1
          variants={itemVariants}
          className="text-5xl md:text-6xl font-bold text-slate-900 dark:text-white mb-6 leading-tight"
        >
          Planos Simples e{" "}
          <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
            Transparentes
          </span>
        </motion.h1>

        <motion.p
          variants={itemVariants}
          className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto"
        >
          Escolha o plano perfeito para sua equipe. Sem taxas ocultas, cancele quando quiser.
        </motion.p>
      </motion.section>

      {/* Pricing Cards */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="container mx-auto px-4 py-12"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className={`relative ${plan.popular ? "md:scale-105" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-0 right-0 flex justify-center">
                  <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </div>
                </div>
              )}

              <div
                className={`h-full p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-lg hover:shadow-2xl transition-all border ${
                  plan.popular
                    ? `border-transparent bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 ring-2 ring-purple-500`
                    : "border-slate-200 dark:border-slate-700"
                }`}
              >
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                  {plan.name}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 mb-6">{plan.description}</p>

                <div className="mb-6">
                  <span className="text-5xl font-bold text-slate-900 dark:text-white">
                    R$ {plan.price}
                  </span>
                  <span className="text-slate-600 dark:text-slate-400">/mês</span>
                </div>

                <Button
                  className={`w-full mb-8 gap-2 ${
                    plan.popular
                      ? `bg-gradient-to-r ${plan.color} hover:opacity-90`
                      : "bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100"
                  }`}
                >
                  Escolher Plano
                  <ArrowRight className="w-4 h-4" />
                </Button>

                <div className="space-y-4">
                  {plan.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
                      <span className="text-slate-600 dark:text-slate-400">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* FAQ Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="container mx-auto px-4 py-20"
      >
        <motion.h2
          variants={itemVariants}
          className="text-4xl font-bold text-center text-slate-900 dark:text-white mb-16"
        >
          Perguntas Frequentes
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {[
            {
              q: "Posso mudar de plano depois?",
              a: "Sim! Você pode fazer upgrade ou downgrade a qualquer momento.",
            },
            {
              q: "Qual é a política de cancelamento?",
              a: "Você pode cancelar sua assinatura a qualquer momento sem penalidades.",
            },
            {
              q: "Vocês oferecem período de teste gratuito?",
              a: "Sim, oferecemos 14 dias de teste gratuito para todos os planos.",
            },
            {
              q: "Quais métodos de pagamento vocês aceitam?",
              a: "Aceitamos cartão de crédito, débito, Pix e boleto bancário.",
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              className="p-6 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700"
            >
              <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                {item.q}
              </h3>
              <p className="text-slate-600 dark:text-slate-400">{item.a}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* CTA Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="container mx-auto px-4 py-20"
      >
        <motion.div
          variants={itemVariants}
          className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-12 text-center text-white shadow-2xl"
        >
          <h2 className="text-4xl font-bold mb-4">Comece sua jornada agora</h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Escolha um plano e comece a gerenciar seus chamados com elegância.
          </p>
          {!isAuthenticated ? (
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="gap-2">
                Entrar e Escolher Plano
                <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
          ) : (
            <Link href="/billing">
              <Button size="lg" variant="secondary" className="gap-2">
                Gerenciar Assinatura
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          )}
        </motion.div>
      </motion.section>

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-950/50 backdrop-blur-sm"
      >
        <div className="container mx-auto px-4 py-8 text-center text-slate-600 dark:text-slate-400">
          <p>&copy; 2026 Sistema de Chamados. Todos os direitos reservados.</p>
        </div>
      </motion.footer>
    </div>
  );
}
