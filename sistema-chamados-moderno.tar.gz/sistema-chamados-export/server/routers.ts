import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  tickets: router({
    list: publicProcedure.query(async () => {
      const { getAllTickets } = await import("./db");
      return getAllTickets();
    }),
    getById: publicProcedure.input((val: any) => ({ id: val.id })).query(async ({ input }) => {
      const { getTicketById } = await import("./db");
      return getTicketById(input.id);
    }),
    create: protectedProcedure.input((val: any) => ({
      title: val.title,
      description: val.description,
      priority: val.priority,
      categoryId: val.categoryId,
    })).mutation(async ({ input, ctx }) => {
      const { createTicketRecord } = await import("./db");
      const ticket = await createTicketRecord({
        title: input.title,
        description: input.description,
        priority: input.priority,
        categoryId: input.categoryId,
        createdById: ctx.user.id,
        status: "novo",
      });
      return ticket;
    }),
    updateStatus: protectedProcedure.input((val: any) => ({
      id: val.id,
      status: val.status,
    })).mutation(async ({ input, ctx }) => {
      const { updateTicketRecord, createTicketHistoryRecord } = await import("./db");
      await updateTicketRecord(input.id, { status: input.status });
      await createTicketHistoryRecord({
        ticketId: input.id,
        changedById: ctx.user.id,
        fieldChanged: "status",
        newValue: input.status,
      });
      return { success: true };
    }),
    getHistory: publicProcedure.input((val: any) => ({ ticketId: val.ticketId })).query(async ({ input }) => {
      const { getTicketHistory } = await import("./db");
      return getTicketHistory(input.ticketId);
    }),
  }),
  categories: router({
    list: publicProcedure.query(async () => {
      const { getAllCategories } = await import("./db");
      return getAllCategories();
    }),
  }),
});

export type AppRouter = typeof appRouter;
