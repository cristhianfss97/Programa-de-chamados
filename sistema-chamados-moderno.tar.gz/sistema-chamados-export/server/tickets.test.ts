import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Tickets Router", () => {
  describe("tickets.list", () => {
    it("should return an array of tickets", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tickets.list();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("tickets.getById", () => {
    it("should return undefined for non-existent ticket", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.tickets.getById({ id: 99999 });

      expect(result).toBeUndefined();
    });
  });

  describe("tickets.create", () => {
    it("should create a ticket with valid input", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const input = {
        title: "Test Ticket",
        description: "This is a test ticket",
        priority: "média" as const,
        categoryId: null,
      };

      const result = await caller.tickets.create(input);

      expect(result).toBeDefined();
    });

    it("should require authentication to create a ticket", async () => {
      const ctx = createMockContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      const input = {
        title: "Test Ticket",
        description: "This is a test ticket",
        priority: "média" as const,
        categoryId: null,
      };

      try {
        await caller.tickets.create(input);
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("tickets.updateStatus", () => {
    it("should require authentication to update status", async () => {
      const ctx = createMockContext();
      ctx.user = null as any;
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.tickets.updateStatus({
          id: 1,
          status: "em_andamento",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("categories.list", () => {
    it("should return an array of categories", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.categories.list();

      expect(Array.isArray(result)).toBe(true);
    });
  });
});
